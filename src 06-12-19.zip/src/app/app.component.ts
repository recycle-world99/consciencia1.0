import { Component, enableProdMode } from '@angular/core';
import { Platform, MenuController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import * as firebase from 'firebase';
import { EmailValidator } from '@angular/forms';
import {AuthenticateService} from './services/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  
  user: any;
  afAuth: any;
  ngxQrcode2 =  ' https://www.npmjs.com/package/ngx-qrcode2 ' ;
  techiediaries =  ' https://www.npmjs.com/~techiediaries ' ;
  letsboot =  ' https://www.letsboot.com/ ' ;



  public paginaPrincipal = [
  {
      title: 'login',
      url: '/login',
      icon: 'log-in'
      },
  ]

  public appPages = [   
    
    {
      title: 'login',
      url: '/login',
      icon: 'log-in'
      },
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
    {
      title:'Meus Dados',
      url:'/contato',
      icon:'contact'
    },
    {
      title: 'Produtos Reciclaveis',
      url: '/list',
      icon: 'basket'
    },
    {
      title:'Trocas de Produtos',
      url: '/compras',
      icon: 'cart'
    },
    {
      title: 'QR Code',
      url: '/qrcode',
      icon: 'qr-scanner'
    },
    {
      title: 'Sair',
      url: '/sair',
      icon: 'power'
    }

  ];

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    public menuCtrl: MenuController,
    private authService: AuthenticateService
  ) {
    //enableProdMode();

    /*this.afAuth.authState.pipe(map(user => user !== null)).subscribe(auth => {
      if (auth) {
           this.menuCtrl.enable(true, 'main');
      }
    });*/

    this.initializeApp();

  }

  initializeApp() {


    if(this.user != null){
      this.paginaPrincipal.length = 0;
    } else{
      this.paginaPrincipal.length = 1;
    }

    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }


}
