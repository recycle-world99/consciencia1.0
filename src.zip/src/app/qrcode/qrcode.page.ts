import {Component} from '@angular/core';
import {BarcodeScanner} from '@ionic-native/barcode-scanner/ngx';
import {HttpClient} from '@angular/common/http';


@Component({
  selector: 'app-qrcode',
  templateUrl: './qrcode.page.html',
  styleUrls: ['./qrcode.page.scss'],
})

export class QRCodePage {
  qrData = null;
  createdcode = null;
  scannedcode= null;
  data;
  encodText: string = '';
  encodeData: any={};
  
 

  constructor(private Scanner: BarcodeScanner, public http:HttpClient) {
 
  }

  
  createCode(){
    
    

    this.encodeData = this.encodText;
    
    /*{
      this.crudService.read_Students().subscribe(data => {
   
        this.qrData = data.map(e => {
          return {
            id: e.payload.doc.id,
            isEdit: false,
            produto: e.payload.doc.data()['produto'],
            quantidade: e.payload.doc.data()['quantidade'],
            valor: e.payload.doc.data()['valor'],
          };
        })
        console.log(this.students);
   
      });*/
    }

  /*scanCode(){
  
     this.Scanner.scan().then(barcodeData => {
     console.log('Barcode data', barcodeData);

     this.scannedData = barcodeData;
  
    })
    
     .catch (err => {
     
     console.log('Error', err);
    
    });
  
  }*/

}


















