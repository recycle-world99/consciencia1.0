import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: 'list.page.html',
  styleUrls: ['list.page.scss']
})



export class ListPage implements OnInit {
  private selectedItem: any;

  prods = [
    {
      titulo: 'Plásticos',valor: '- Pontos por (Kg)', url: '',
      
      subProds: [
        { titulo: 'PVC',valor: 'R$:6,29', url: ''},
        { titulo: 'PET',valor: 'R$:5,99', url: ''},
        { titulo: 'Polietileno',valor: 'R$:4,29', url: '' },
        { titulo: 'Polipropileno',valor: 'R$:2,79', url: ''},
        { titulo: 'Outros plásticos',valor: 'R$:3,75', url: ''},
      ]
    },
    
    {
      titulo: 'Papeis',valor: '- Pontos por (Kg)', url: '',

      subProds: [
        {titulo: 'Jornal',valor: 'R$:3,79', url: ''}, 
        {titulo: 'Cartolina',valor: 'R$:12,89', url: ''},
        {titulo: 'Papelão',valor: 'R$:5,99', url: ''},
        {titulo: 'Reciclável',valor: 'R$:1,79', url: ''},
        {titulo: 'Papel fotográfico',valor: 'R$:1,55', url: ''},
        {titulo: 'Outos',valor: 'R$:2,99', url: ''},
      ]
    },

    { titulo: 'Vidros',valor: '- Pontos por (Kg)', url: '',

      subProds:[
        {titulo: 'Espelhado',valor: 'R$:5,99', url: '',},
        {titulo: 'Laminado',valor: 'R$:11,90', url: ''},
        {titulo: 'Colorido',valor: 'R$:7,15', url: ''},
        {titulo: 'Duplo',valor: 'R$:1,49', url: ''},
        {titulo: 'Especias',valor: 'R$:2,89', url: ''},
      ]

    },
    { titulo: 'Metais',valor: '- Pontos por (Kg)', url: '',

    subProds:[
      {titulo: 'Alumínio',valor: 'R$:1,99', url: '',},
      {titulo: 'Cobre',valor: 'R$:2,49', url: ''},
      {titulo: 'Ferro',valor: 'R$:3,59', url: ''},
      {titulo: 'Níquel',valor: 'R$:6,20', url: ''},
      {titulo: 'Chumbo',valor: 'R$:6,69', url: ''},
      {titulo: 'Outros Metais',valor: 'R$:6,69', url: ''},
    ]

    },
    { titulo: 'Materiais Organicos',valor:'- Pontos por (Kg)', url: '',

    subProds:[
      {titulo: 'Materias em gerais',valor: 'R$:49,69', url: '',},
      ]
    },
    {
      titulo: 'Pilhas e Baterias',valor: '- Pontos por (Kg)', url: '',
      
      subProds: [
        { titulo: 'Pilha AAA',valor: 'R$:', url: ''},
        { titulo: 'Pilha AA',valor: 'R$:', url: ''},
        { titulo: 'Pilha A',valor: 'R$:', url: '' },
        { titulo: 'Bateria 9V',valor: 'R$:', url: ''},
        { titulo: 'Bateria de Celular',valor: 'R$:', url: ''},
      ]
    }
    ];

  private icons = [
    'flask',
    'wifi',
    'beer',
    'football',
    'basketball',
    'paper-plane',
    'american-football',
    'boat',
    'bluetooth',
    'build'
  ];
  public items: Array<{ title: string; note: string; icon: string }> = [];
  constructor() {
    for (let i = 1; i < 11; i++) {
      this.items.push({
        title: 'Item ' + i,
        note: 'This is item #' + i,
        icon: this.icons[Math.floor(Math.random() * this.icons.length)]
      });
    }
  }

  ngOnInit() {
  }
  // add back when alpha.4 is out
  // navigate(item) {
  //   this.router.navigate(['/list', JSON.stringify(item)]);
  // }
}