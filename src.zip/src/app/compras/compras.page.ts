import { Component } from '@angular/core';
import { LoadingController } from '@ionic/angular';
import { ServicesService} from '../services.service';
import {ToastController} from '@ionic/angular';
import {NavController} from '@ionic/angular';

@Component({
  selector: 'app-compras',
  templateUrl: 'compras.page.html',
  styleUrls: ['compras.page.scss'],
})
export class ComprasPage {
 
  produto: string  
  quantidade: number
  valor:number 
  total:number

  constructor( public service: ServicesService, public LoadingCtrl:LoadingController, public NavCtlr:NavController ) {}

  criarRegistro (){
     let mercadoria = {};
     mercadoria ['produto'] = this.produto;
     mercadoria ['quantidade'] = this.quantidade;
     mercadoria ['valor'] = this.valor;
     /*mercadoria ['total'] = this.total;*/
     
     this.service.create_novamercadora(mercadoria).then(async resp=>{
  
     this.produto = ""; 
     this.valor = 0;
     this.quantidade = 0;
     /*this.total = 0;*/

   
     /*if (this.valor>0){
       this.total = this.quantidade * this.valor

       const loading = await this.LoadingCtrl.create({
       message: 'Hellooo',
       duration: 2000
       });
       await loading.present();
    
      const { role, data } = await loading.onDidDismiss();
      
      console.log('Loading dismissed!');}*/ 
      
      
    }); 
    
  }

}